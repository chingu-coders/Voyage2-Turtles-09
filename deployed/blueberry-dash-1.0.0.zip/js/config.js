const config = {
  unsplashApplicationId: "51eeacda52a858956883fcd86384424f78d38da8fb4f8b61b65723e41223d6b1",
  edamamAppId: "373a2755",
  edamamAppKey: "5e414263cb40da6abf1019a550333f43"
}
